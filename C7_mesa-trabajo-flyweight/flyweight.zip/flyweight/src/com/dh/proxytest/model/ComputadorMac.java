package com.dh.proxytest.model;

public class ComputadorMac extends Computador{

    public ComputadorMac() {
        super(500, 16);
    }
}
