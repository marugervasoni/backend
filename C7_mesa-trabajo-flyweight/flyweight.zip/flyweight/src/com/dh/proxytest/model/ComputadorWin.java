package com.dh.proxytest.model;

public class ComputadorWin extends Computador{

    public ComputadorWin() {
        super(128, 2);
    }
}
