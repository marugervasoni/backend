package com.dh.medicamentos.dao.impl;

import com.dh.medicamentos.dao.IDao;
import com.dh.medicamentos.model.Medicamento;

public class MedicamentoDaoMariaDb implements IDao<Medicamento> {
    @Override
    public Medicamento guardar(Medicamento medicamento) {
        return null;
    }

    @Override
    public Medicamento buscar(Integer id) {
        return null;
    }
}
