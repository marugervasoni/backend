CREATE TABLE if not exists odontologos(
    numDeMatricula int ,
    nombre varchar(255),
    apellido varchar (255));