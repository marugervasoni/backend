package com.company.service;

import com.company.model.Odontologo;
import com.company.persistence.IDao;

import java.util.List;

public class OdontologoService {

    private IDao<Odontologo> odontologoIDao;

    public OdontologoService() {
    }

    public IDao<Odontologo> getOdontologoIDao() {
        return odontologoIDao;
    }

    public void setOdontologoIDao(IDao<Odontologo> odontologoIDao) {
        this.odontologoIDao = odontologoIDao;
    }

    public Odontologo registrar (Odontologo o){
        return odontologoIDao.registrar(o);
    }
    public List<Odontologo> listar() {
        return odontologoIDao.listar();
    }
}
