package test.odontologo.service;

import com.company.model.Odontologo;
import com.company.persistence.impl.OdontologoDaoH2;
import com.company.service.OdontologoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class OdontologoServiceTest {


    @Test
    public void deberíaListarOdontologosPertenecientesALaBD(){
        //DADOS
        OdontologoService odontologoService = new OdontologoService();
        odontologoService.setOdontologoIDao(new OdontologoDaoH2());

            Odontologo odontologo = new Odontologo();
            odontologo.setNumDeMatricula(12345678);
            odontologo.setNombre("Gustavo");
            odontologo.setApellido("Cerati");
            odontologoService.registrar(odontologo);


        //CUANDO
        odontologoService.listar();

        //ENTONCES
        Assertions.assertTrue(odontologoService.registrar(odontologo) != null);
    }

}