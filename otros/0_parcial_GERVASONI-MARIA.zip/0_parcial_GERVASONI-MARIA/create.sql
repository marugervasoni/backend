drop table if exists odontologos; create table odontologos (
    numDeMatricula int primary key,
    nombre varchar(255),
    apellido varchar (255));