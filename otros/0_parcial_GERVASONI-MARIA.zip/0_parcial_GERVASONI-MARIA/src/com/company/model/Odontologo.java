package com.company.model;

public class Odontologo {

    private int numDeMatricula;
    private String nombre;
    private String apellido;

    public Odontologo(int numDeMatricula, String nombre, String apellido) {
        this.numDeMatricula = numDeMatricula;
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public int getNumDeMatricula() {
        return numDeMatricula;
    }

    public void setNumDeMatricula(int numDeMatricula) {
        this.numDeMatricula = numDeMatricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        return "Odontologo{" +
                "numDeMatricula=" + numDeMatricula +
                ", nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                '}';
    }
}
