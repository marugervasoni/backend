package com.company.persistence.impl;

import com.company.model.Odontologo;
import com.company.persistence.IDao;
import org.apache.log4j.Logger;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OdontologoDaoH2 implements IDao<Odontologo> {

    public static Logger logger = Logger.getLogger(OdontologoDaoH2.class);

    private final static String JDBC_DRIVER = "org.h2.Driver";
    private final static String URL = "jdbc:h2:~/clinicaOdontologica";
    private final static String USER = "sa";
    private final static String PASS = "";

    @Override
    public Odontologo registrar(Odontologo odontologo) {
        Connection connection = null;
        PreparedStatement pstmt = null;

        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(URL, USER, PASS);

            pstmt = connection.prepareStatement("INSERT INTO odontologos VALUES (?,?,?)");
            pstmt.setString(2, odontologo.getNombre());
            pstmt.setString(3, odontologo.getApellido());

            logger.info("inserting values in given database...");

            pstmt.executeUpdate();
            pstmt.close();

        } catch (ClassNotFoundException ex) {
            logger.error("Error: unable to load driver class!");
            System.exit(1);
        } catch (SQLException e) {
            logger.error(e.getMessage());
        }
        return odontologo;
    }

    @Override
    public List<Odontologo> listar() {
        Connection connection = null;
        PreparedStatement pstmt = null;
        List<Odontologo> odontologos = new ArrayList<>();

        try {
            Class.forName(JDBC_DRIVER);
            connection = DriverManager.getConnection(URL, USER, PASS);

            pstmt = connection.prepareStatement("SELECT * FROM odontologos");

            ResultSet result = pstmt.executeQuery();

            while (result.next()) {
                int numDeMatricula = result.getInt("numDeMatricula");
                String nombre = result.getString("nombre");
                String apellido = result.getString("apellido");

                //me conviene el constructor vacio? porque en la prueba no esta vacio
                Odontologo odontologo = new Odontologo();
                odontologo.setNumDeMatricula(numDeMatricula);
                odontologo.setNombre(nombre);
                odontologo.setApellido(apellido);

                odontologos.add(odontologo);
            }
            pstmt.close();

        } catch (ClassNotFoundException e) {
            logger.error("Error: unable to load driver class!");
            System.exit(1);
        } catch (SQLException e) {
            logger.error(e.getMessage());
        }
        return odontologos;
    }
}

