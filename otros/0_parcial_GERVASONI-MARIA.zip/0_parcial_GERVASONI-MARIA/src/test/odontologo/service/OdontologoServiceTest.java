package test.odontologo.service;

import com.company.model.Odontologo;
import com.company.persistence.impl.OdontologoDaoH2;
import com.company.service.OdontologoService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class OdontologoServiceTest {

    private OdontologoService odontologoService = new OdontologoService(new OdontologoDaoH2());

    //revisar que esl test funcione

    @Test
    public void deberíaListarOdontologosPertenecientesALaBD(){
        //DADOS
        Odontologo odontologo = new Odontologo(12345,"Gustavo","Cerati");
        //Odontologo odontologo2 = new Odontologo(13345,"Carlos","Solari");
        //Odontologo odontologo3 = new Odontologo(14345,"Rodolfo","Paez");
        odontologoService.registrar(odontologo);
        //odontologoService.registrar(odontologo2);
        //odontologoService.registrar(odontologo3);

        //CUANDO
        odontologoService.listar();

        //ENTONCES
        Assertions.assertTrue(odontologoService.registrar(odontologo) != null);
    }

}