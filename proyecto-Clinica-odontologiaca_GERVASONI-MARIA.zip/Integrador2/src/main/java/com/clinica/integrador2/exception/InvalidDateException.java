package com.clinica.integrador2.exception;

public class InvalidDateException extends Exception {

    public InvalidDateException(String message) {
        super(message);
    }
}
