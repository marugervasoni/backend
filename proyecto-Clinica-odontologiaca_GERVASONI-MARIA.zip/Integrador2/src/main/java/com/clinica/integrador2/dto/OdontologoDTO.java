package com.clinica.integrador2.dto;

import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class OdontologoDTO {

    private Integer id;
    private String nombre;
    private String apellido;
    private Integer matricula;
}
